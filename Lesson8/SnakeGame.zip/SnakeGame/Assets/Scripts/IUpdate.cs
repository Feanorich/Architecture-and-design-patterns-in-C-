﻿namespace Snake
{
    public interface IUpdate
    {
        void GameUpdate(float deltaTime);
    }
}